import { Component} from '@angular/core';
import { DataStorageService } from '../shared/data-storage.service';

@Component ({

    selector: 'app-header',
    templateUrl: './header.component.html',
})
export class HeaderComponent{
constructor(private datRec:DataStorageService){}
    onSaveData(){
        let a= confirm('Are you sure!');
        if (a){
            this.datRec.storeRecipe();
        }

    }
    onFatchData(){
     
       
        this.datRec.fetchRecipe().subscribe();
    }


}