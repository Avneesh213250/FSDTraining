import { Recipe } from './recipe.model';
import { EventEmitter, Injectable } from '@angular/core';
import { Ingredient } from '../shared/Ingredient.model';
import { ShoppingListService } from '../shopping-list/shopping-list.service';
import { Subject } from 'rxjs';
@Injectable()

export class RecipeService{
  constructor(private slService:ShoppingListService){

  }
  changeRecipe= new Subject<Recipe[]>();
    // selectedRecipe= new EventEmitter<Recipe>();

    recipes:Recipe[]=[

        new Recipe('A test recipe', 'A simple test', 'https://www.bbcgoodfood.com/sites/default/files/recipe-collections/collection-image/2013/05/indian.jpg',[
          new Ingredient('Meat', 1),
          new Ingredient('French Frice', 20)
        ]), 
        new Recipe('A test recipe1', 'A simple test1', 'https://www.bbcgoodfood.com/sites/default/files/recipe-collections/collection-image/2013/05/indian.jpg',[
          new Ingredient('Bread', 1),
          new Ingredient('Fish',2)
        ])
      ];
      getRecipe(){
         return this.recipes.slice();
      }
      addIngrdients(ingredient: Ingredient[]){
       this.slService.addIngredientfromRecipe(ingredient);
      }
      getRecipeById(index: number){
       return this.recipes[index];
      }
      addRecipe(recipe:Recipe){
        this.recipes.push(recipe);
        this.changeRecipe.next(this.recipes.slice());
      }
      updateRecipe(index:number,newRecipe:Recipe){
        this.recipes[index]=newRecipe;
        this.changeRecipe.next(this.recipes.slice());
      }

      deleteRecipe(index:number){
this.recipes.splice(index,1);
this.changeRecipe.next(this.recipes.slice());
      }

      setRecipe(recipesGet:Recipe[]){
      this.recipes=recipesGet;
      this.changeRecipe.next(this.recipes.slice());
      }
}