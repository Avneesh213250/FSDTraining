import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RecipeService } from '../recipes/recipe.service';
import { Recipe } from '../recipes/recipe.model';
import { map, tap } from 'rxjs/operators'

@Injectable({providedIn:'root'})
export class DataStorageService{
constructor(private http:HttpClient, private rcService:RecipeService){}
storeRecipe(){
const recipes= this.rcService.getRecipe();
this.http.put('https://myfirstangapp-8d109.firebaseio.com/recipes.json', recipes).subscribe(
    response=>{
        console.log(response);
    }
);
}
// fatchRecipe(){
//     this.http.get<Recipe[]>('https://myfirstangapp-8d109.firebaseio.com/recipes.json')
//     .pipe(map(recipes=>{
//         return recipes.map(recipe=>{
//             return {...recipe, ingerdients: recipe.ingredients? recipe.ingredients:[]};
//         });
//     }))
//     .subscribe(
//         response=>{
//             this.rcService.setRecipe(response);
//             console.log(Response);
//         }
//     );
// }
fetchRecipe() {
    return this.http
      .get<Recipe[]>(
        'https://myfirstangapp-8d109.firebaseio.com/recipes.json'
      )
      .pipe(
        map(recipes => {
          return recipes.map(recipe => {
            return {
              ...recipe,
              ingredients: recipe.ingredients ? recipe.ingredients : []
            };
          });
        }),
        tap(recipes => {
          this.rcService.setRecipe(recipes);
        })
      )
  }
}