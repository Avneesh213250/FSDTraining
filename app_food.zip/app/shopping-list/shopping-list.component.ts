import { Component, OnInit, OnDestroy } from '@angular/core';
import { Ingredient } from '../shared/Ingredient.model';
import { ShoppingListService } from './shopping-list.service';
import { Subscription } from 'rxjs';
import { ThrowStmt } from '@angular/compiler';


@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit, OnDestroy{
ingredients:Ingredient[];
subjectSubscription:Subscription;
  constructor(private slService: ShoppingListService) { }
 
  ngOnInit(): void {
    this.ingredients=this.slService.getIngredients();
    this.subjectSubscription=this.slService.changeIngredients.subscribe(
      (ingredientsnew: Ingredient[])=>{
        this.ingredients=ingredientsnew;
      }
    );
  }
ngOnDestroy(){
this.subjectSubscription.unsubscribe();
}
onEditItem(index:number){
this.slService.startedEditing.next(index);
}

}
