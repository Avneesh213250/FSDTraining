import { Ingredient } from '../shared/Ingredient.model';
import { EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import { ThrowStmt } from '@angular/compiler';

export class ShoppingListService{
    //changeIngredients= new EventEmitter<Ingredient[]>();

    startedEditing=new Subject<any>();
    changeIngredients= new Subject<Ingredient[]>();
    ingredients:Ingredient[]=[
        new Ingredient('Apple', 5),
        new Ingredient('Tomatos', 10)
        ];

    addIngredient(newIngredient: Ingredient){
            this.ingredients.push(newIngredient);
            this.changeIngredients.next(this.ingredients.slice());
              }
    getIngredients(){
        return this.ingredients.slice();
        //return this.ingredients;
    }
    addIngredientfromRecipe(ingredients1:Ingredient[]){
    this.ingredients.push(...ingredients1);
    
    this.changeIngredients.next(this.ingredients.slice());
    // this.ingredients.forEach(element => {
    //     console.log(element.name+"  -  "+element.amount);
    // });
    }
   getIngredient(index:number){
    return this.ingredients[index];
   }
   updateIngredient(index:number, newingredient:Ingredient){

    this.ingredients[index]=newingredient;

    this.changeIngredients.next(this.ingredients.slice())
  }
  deleteIngredient(index:number){
      this.ingredients.splice(index,1);
      this.changeIngredients.next(this.ingredients.slice())
  }
}