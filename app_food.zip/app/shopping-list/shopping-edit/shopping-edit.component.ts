import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { Ingredient } from 'src/app/shared/Ingredient.model';
import { ShoppingListService } from '../shopping-list.service';
import { NgForm } from '@angular/forms';
import { Subscribable, Subscription } from 'rxjs';
import { registerLocaleData } from '@angular/common';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit , OnDestroy{
  // @Output() newIngerdient=new EventEmitter<Ingredient>();
  // //@ViewChild('inputName') inputName :ElementRef;
 @ViewChild('f') signForm:NgForm;
  mysub: Subscription;
  editMode=false;
  editedItemIndex:number;
  editItem:Ingredient;
  constructor(private slSrevice:ShoppingListService) { }

  ngOnInit(): void {

    this.mysub=this.slSrevice.startedEditing.subscribe(
      (index:number)=>{
        this.editedItemIndex=index;
        this.editMode=true;
        this.editItem=this.slSrevice.getIngredient(index);
        this.signForm.setValue({
          name:this.editItem.name,
          amount:this.editItem.amount
        })
      }
    );
  }
  addIngerdient(form:NgForm){
const value=form.value;
const newingrediant=new Ingredient(value.name, value.amount);
if(this.editMode){

  this.slSrevice.updateIngredient(this.editedItemIndex, newingrediant);
  
}else{
 
  this.slSrevice.addIngredient(newingrediant);
 
}
this.editMode=false;
form.reset();

  }
  ngOnDestroy(): void {
   
    this.mysub.unsubscribe();
  }

  onclear(){
    this.signForm.reset();
    this.editMode=false
  }
  onDelete(){
    this.slSrevice.deleteIngredient(this.editedItemIndex);
    this.onclear();
  }
}
