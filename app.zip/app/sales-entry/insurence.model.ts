export class Insurence{
    constructor(public insurence:string, public policy:string, public matuityDate:Date){}
}