export class CreditCard{
    constructor(public creditCardNum:number, public validity:Date){}
}