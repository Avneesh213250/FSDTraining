import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { CreditCard } from './creditCart.model';
import { Insurence } from './insurence.model';
import { SalesEntryService } from './sales-entry.service';
import { Sales } from './sales-entry.model';

@Component({
  selector: 'app-sales-entry',
  templateUrl: './sales-entry.component.html',
  styleUrls: ['./sales-entry.component.css']
})
export class SalesEntryComponent implements OnInit {

  @ViewChild('signUpForm') signUpForm:NgForm;

  constructor(
    private router:Router, 
    private route:ActivatedRoute,
    private salesService:SalesEntryService) { }

    sales_typetest:string=''


customername:string='';
salestype:string='';
creditCardNum:number=null;
validity:Date=new Date();
insurence:string=null;
policy:string='';
matuityDate:Date=new Date();
createdDate:Date=new Date();
createdBy:string='';

ngOnInit(): void {
}
onSubmit(){

  let officername= sessionStorage.getItem('name');
let officerid=+sessionStorage.getItem('userid');
  this.customername= this.signUpForm.value.customername;
 this.salestype=this.signUpForm.value.salestype;
 console.log(officername);
 
 this.creditCardNum=this.signUpForm.value.creditCardNum;
 this.validity=this.signUpForm.value.validity;
 this.insurence=this.signUpForm.value.insurence;
 this.policy=this.signUpForm.value.policy;
 this.matuityDate= this.signUpForm.value.matuityDate;
 let creditCard:CreditCard= null;
 let insurenceObj:Insurence= null;
 let salesid:number=null;
 if(this.salestype==='Insurence'){
  salesid=1;
 }else{
  salesid=2;
 }
 if(this.salestype!=='Insurence'){
  creditCard= new CreditCard(this.creditCardNum, this.validity);
 }
 if(this.salestype==='Insurence'){
  insurenceObj= new Insurence(this.insurence, this.policy, this.matuityDate);
 }
 const data=new Sales(null, this.customername,creditCard, insurenceObj, salesid,this.salestype, new Date(), officername,officerid);
 console.log(data);
 
 this.salesService.saveSalesEntry(data).subscribe(
   element=>{
    console.log(data);
    alert("Successfully Submited");
    this.router.navigate(['home/salesList']);
   }
 );
}
onCancel(){
 this.signUpForm.reset();
   }
 }

