export class User{

    constructor(public userid:number, public password:string, public usertype:string){}
}