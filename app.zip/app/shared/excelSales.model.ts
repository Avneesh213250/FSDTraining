
export class ExcelModel{
    constructor(public id:number, public customername:string, public creditCard:string, public insurence:string,public salesId:number, public salestype:string, public createdDate:Date, public createdBy:string, public officerid:number){}
}