export class Officer{


    constructor(public Branch_Id:string, public officerName:string, public phoneNum:number, public officerEmail:string, public officerAdress:string, public status:string){}
}